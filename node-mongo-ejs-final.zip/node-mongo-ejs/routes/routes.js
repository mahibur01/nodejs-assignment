const router = require("express").Router();
const pageController = require("../controllers/page.controller");


router.get("/", pageController.homePage);
router.get("/all-categories", pageController.categoryPage);
router.get("/single-post", pageController.singlePostPage);
router.get("/category-posts", pageController.singlePostPage);


// // Category Post
// app.get('/category-posts', function (req, res) {
//   res.render('pages/category-posts');
// });


module.exports = router;