const categoryController = require("../controllers/admin/category.controller");
const postController = require("../controllers/admin/post.controller");
const multer = require('multer')
//const upload = multer({ dest: "../public/images/posts/" })

const router = require("express").Router();
const { v4: uuidv4 } = require('uuid');
const pageController = require("../controllers/page.controller");




const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'public/images')
  },
  filename: function (req, file, cb) {
    console.log(file);
    var fileName = uuidv4() + "." + file.originalname.split(".")[1];
    cb(null, fileName)
  }
})

const upload = multer({ storage: storage })


router.post('/posts', upload.single('post_image'), postController.save);

// router.route("/upload")
//     /* replace foo-bar with your form field-name */
//     .post(upload.single("foo-bar"), function(req, res){
//        [...]
//     })


//router.post("/posts", upload.single('uploaded_file'), postController.save);

//router.route("/posts").post(upload.single("post_image"), postController.save);

router.get("/posts", postController.getAll);
router.get("/create-post", postController.createPost);


router.post('/categories', upload.single('cat_image'), categoryController.saveCategory);
// router.post("/categories", categoryController.saveCategory);
router.get("/categories", categoryController.getAllCategories);
router.get("/create-category", categoryController.createCategory);
router.get("/dashboard", pageController.adminDashboard);

// // Admin Dashboard 
// app.get('/dashboard', function (req, res) {
//   res.render('pages/admin/dashboard');
// });

// // Categories
// app.get('/categories', function (req, res) {
//   res.render('pages/admin/categories');
// });

// // Create Categories
// app.get('/create-category', function (req, res) {
//   res.render('pages/admin/create-category');
// });





module.exports = router;