const mongoose = require("mongoose");

// Database Connection
async function connectDb() {
  mongoose.connect("mongodb://localhost:27017/test_db");
}

module.exports = {
  connectDb: connectDb,
};